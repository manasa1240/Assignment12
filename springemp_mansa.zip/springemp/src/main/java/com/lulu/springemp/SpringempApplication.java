package com.lulu.springemp;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

//File needed to kick start the application.

@SpringBootApplication        //This annotation will do automatic configuration.
public class SpringempApplication {

	public static void main(String[] args) {
		SpringApplication.run(SpringempApplication.class, args);
	}

}
