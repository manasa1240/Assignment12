package com.lulu.springemp.controller;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RestController;

import com.lulu.springemp.entity.Helpdesk;
import com.lulu.springemp.repo.HelpRepo;

@CrossOrigin
@RestController

public class ControllerHelp {
	
	
			@Autowired
		    HelpRepo helpRepo;
		   
		    @PostMapping("/addhelp")// End Point
		    public Helpdesk createorders(@RequestBody Helpdesk help) {
		        return helpRepo.save(help);
		    }
		    
		    @GetMapping("/gethelp")
		    public List<Helpdesk> gethelp(){
		    	
		    	return helpRepo.findAll();
		    }
		    
	
	
}


