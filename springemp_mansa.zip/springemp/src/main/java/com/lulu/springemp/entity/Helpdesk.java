package com.lulu.springemp.entity;

import java.sql.Date;
import java.time.LocalDate;

import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.Table;

@Entity
@Table

public class Helpdesk {
	
	@Id
	@GeneratedValue(strategy = GenerationType.AUTO)
	
int id;
String name;
String Complaint_Desk;
LocalDate ordersdate;


public int getId() {
	return id;
}
public void setId(int id) {
	this.id = id;
}
public String getName() {
	return name;
}
public void setName(String name) {
	this.name = name;
}
public String getComplaint_Desk() {
	return Complaint_Desk;
}
public void setComplaint_Desk(String complaint_Desk) {
	Complaint_Desk = complaint_Desk;
}
public LocalDate getOrdersdate() {
	return ordersdate;
}
public void setOrdersdate(LocalDate ordersdate) {
	this.ordersdate = ordersdate;
}
public Helpdesk(int id, String name, String complaint_Desk, LocalDate ordersdate) {
	super();
	this.id = id;
	this.name = name;
	Complaint_Desk = complaint_Desk;
	this.ordersdate = ordersdate;
}
public Helpdesk() {
	super();
	// TODO Auto-generated constructor stub
}
@Override
public String toString() {
	return "Helpdesk [id=" + id + ", name=" + name + ", Complaint_Desk=" + Complaint_Desk + ", ordersdate=" + ordersdate
			+ "]";
}




}
