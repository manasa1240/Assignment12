package com.lulu.springemp;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class SpringempApplicationTests {

	@Test
	void contextLoads() {
	}

}
